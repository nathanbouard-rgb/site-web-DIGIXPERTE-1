# DIGIXPERTE — Sources du site web

## Structure du projet

```
digixperte-source/
│
├── index.html              ← Point d'entrée (références CSS/JS externes)
├── digixperte.html         ← ✅ VERSION COMPLÈTE AUTONOME (tout-en-un)
├── logo.jpg                ← Logo DIGIXPERTE
│
├── css/
│   └── main.css            ← Tous les styles (global + pages audit/ressources/contact)
│
├── js/
│   └── main.js             ← Navigation SPA, formulaires, lightning bolt, simulateur, FAQ
│
└── pages/
    ├── nav.html            ← Barre de navigation + menu mobile
    ├── home.html           ← Page d'accueil (hero, services, cas clients, FAQ…)
    ├── blog.html           ← Liste des articles + 10 articles complets
    ├── services.html       ← 6 pages services (SEO, SEA, Meta, Site, CM, Branding)
    ├── legal.html          ← 3 pages légales (mentions, confidentialité, cookies)
    ├── audit.html          ← Page audit gratuit + formulaire
    ├── ressources.html     ← Page ressources (lead magnet, livres blancs, blog, partenaire)
    └── contact.html        ← Page contact + formulaire détaillé
```

## Utilisation

### Option 1 — Fichier tout-en-un (recommandé pour la mise en ligne rapide)
Utilisez directement **`digixperte.html`** — c'est le fichier SPA complet,
autonome, qui n'a besoin d'aucun autre fichier (logo en base64 intégré).

### Option 2 — Architecture multi-fichiers (pour développement/intégration CMS)
Les fichiers dans `pages/`, `css/` et `js/` sont les sources organisées.
Le logo est dans `logo.jpg` et doit être référencé dans les pages HTML.

## Personnalisations à faire

### Lien partenaire (page Ressources)
Dans `pages/ressources.html`, chercher `id="partnerLink"` et remplacer `href="#"` par l'URL réelle.

### PDF Lead Magnet (page Ressources)
Dans `pages/ressources.html`, chercher `// TODO` dans la fonction `submitLM()` et
décommenter la ligne `window.open('URL_DU_FICHIER', '_blank')` avec l'URL de votre PDF.

### Formulaires (back-end)
Les formulaires sont actuellement en front-end uniquement.
Pour recevoir les données, connecter à :
- Un service SMTP (ex: Resend, Brevo, Mailgun)
- Un formulaire tiers (ex: Tally, Typeform, Netlify Forms)
- Votre propre back-end PHP/Node.js

### Téléphone
Chercher `+33 6 00 00 00 00` dans tous les fichiers et remplacer par le vrai numéro.

## Identifiants back-office admin

Fichier : `digixperte-admin.html`
- Login : `admin`
- Mot de passe : `digixperte2025`

⚠️ Changer le mot de passe avant la mise en ligne !

## Technologies utilisées

- HTML5 / CSS3 / JavaScript vanille
- Google Fonts (Playfair Display + DM Sans)
- Lucide Icons (CDN)
- Aucun framework JS — fonctionne sans Node.js ni build system

## Contact

DIGIXPERTE — Nathan Bouard
contact@digixperte.fr
494 Rue Léon Blum, 34000 Montpellier
RCS : 937 482 974 RCS Montpellier
